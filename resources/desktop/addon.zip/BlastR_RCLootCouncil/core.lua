-- BlastR — RCLootCouncil integration.
--
-- Wishlist columns: adds %, BiS, List, Eq, BlastR-info to the RC voting
-- frame, driven entirely by BlastRWishlistData populated by the bridge.
--
-- Loot history: batch-scans RC's persistent history (RCLootCouncilLootDB)
-- via RC:GetHistoryDB() — same approach as wowaudit. Each scan emits any
-- entry whose RC-stamped `id` we haven't seen before into BlastROutboxEvents
-- so the bridge can push it to blastr.pro. Dedup is server-side on
-- `external_id` (RC's id), with a local `BlastRSeenExternalIds` set that
-- keeps repeat scans cheap.
--
-- Scan triggers: PLAYER_LOGIN, RCMLLootHistorySend (RC fires it on award),
-- and `/blastr scanloot` manual. The RCMLLootHistorySend hook gives us
-- "real-time" feel without the fragility of parsing the message args —
-- we just kick the scanner and let it find the freshly-written row.
--
-- Test helpers:
--   /blastr test [count]      — start an RC test session with items
--                               that are actually in someone's wishlist;
--                               each picked item gets a random difficulty
--                               override so awarding it produces a
--                               loot_distribution row stamped with that
--                               difficulty regardless of where the player
--                               currently is.
--   /blastr scanloot          — manual scan, useful for debugging.
--   /blastr stats             — dump local state (wishlist + scanner).
--   /blastr probeitem <id>    — find an item id across all wishlists.
--   /blastr resolve <Name-Realm> — debug char-key canonicalisation.

-- ============================================================
--  SavedVariables (declared in the .toc; just shapes here)
-- ============================================================
BlastROutboxSchema             = BlastROutboxSchema or 1
BlastROutboxEvents             = BlastROutboxEvents or {}
BlastROutboxLastDrainedAt      = BlastROutboxLastDrainedAt or nil
BlastROutboxLastDrainedSeq     = BlastROutboxLastDrainedSeq or 0
BlastROutboxSyncRequestedEpoch = BlastROutboxSyncRequestedEpoch or 0

-- Idempotency cache for the loot scanner. Survives /reload via SV.
-- Keyed by RC's `entry.id` (epoch-counter string), value `true`. We
-- rely on it to skip already-pushed entries on every scan tick; the
-- backend's UNIQUE on external_id is the real correctness guard, this
-- set just keeps the outbox lean.
BlastRSeenExternalIds          = BlastRSeenExternalIds or {}

-- Per-session monotonic sequence. Resets on /reload; the bridge reads
-- it for diagnostics, server-side dedup uses external_id.
local nextSeq = (BlastROutboxLastDrainedSeq or 0) + 1

-- ============================================================
--  Helpers
-- ============================================================

local function nowISO()
    return date("!%Y-%m-%dT%H:%M:%SZ")
end

-- "Name-RealmDisplay" → "Name-realm-slug". RC delivers the winner key
-- in display-name form ("Tarren Mill"); BlastRWishlistData keys are
-- slugged ("tarren-mill"). Slugify by lowercasing and dashing.
local function slugifyRealm(realm)
    if not realm or realm == "" then return "" end
    return realm:lower():gsub("['’]", ""):gsub("%s+", "-")
end

local function fullCharKey(name, realm)
    return name .. "-" .. slugifyRealm(realm)
end

local function splitFullName(full)
    local n, r = full:match("^([^%-]+)%-(.+)$")
    if not n then
        return full, slugifyRealm(GetRealmName and GetRealmName() or "")
    end
    return n, slugifyRealm(r)
end

-- Difficulty id → our single-letter token.
local DIFF_TOKEN = {
    [14] = "N", [15] = "H", [16] = "M", [17] = "R",  -- raid
    [3]  = "N", [4]  = "H", [5]  = "M", [6]  = "R",  -- legacy raid
}

-- Map RC's responseID to our method enum. RC's defaults:
--   1 = "Mainspec/Need", 2 = "Offspec/Greed". Award reasons (Disenchant,
--   Bank, Free…) map to "trash"/"free"; we trust the canonical text on
--   the response object more than the numeric id and let the backend
--   carry the full label too.
local function methodFromResponse(responseID, responseText)
    if responseID == 1 then return "ms" end
    if responseID == 2 then return "os" end
    if type(responseText) == "string" then
        local lower = responseText:lower()
        if lower:find("bis") then return "bis" end
        if lower:find("disenchant") or lower:find("vendor") or lower:find("trash") then return "trash" end
    end
    return "free"
end

-- ============================================================
--  Module registration
-- ============================================================

local addon, RC, RCVotingFrame, mod
local function tryRegister()
    local LibStub = _G.LibStub
    local AceAddon = LibStub and LibStub("AceAddon-3.0", true)
    if not AceAddon then return false end
    addon = AceAddon:GetAddon("RCLootCouncil", true)
    if not addon then return false end
    RC = addon
    RCVotingFrame = addon:GetModule("RCVotingFrame", true)
    if not RCVotingFrame then return false end

    if RC:GetModule("BlastR", true) then
        mod = RC:GetModule("BlastR")
    else
        mod = RC:NewModule("BlastR", "AceConsole-3.0", "AceEvent-3.0", "AceHook-3.0", "AceTimer-3.0")
    end
    return true
end

-- Forward declarations: continueInit is module-scoped because both the
-- PLAYER_LOGIN handler and the lazy-retry path inside startTest need it.
-- It uses scanLootDB / injectColumns which appear lower in the file —
-- forward decls keep references resolvable.
local continueInit
local ensureRegistered

-- Single source of truth for "RC available + module wired up". Returns
-- true when RC is registered and our cross-cutting init (column inject,
-- ML:Test monkey-patch, message hooks) has been installed. Called from
-- PLAYER_LOGIN, the retry frame, and lazily from startTest so a slash
-- command still works even if our load order beat RC's NewAddon by a
-- frame.
local _initDone = false
ensureRegistered = function()
    if not RC and not tryRegister() then return false end
    if _initDone then return true end
    if continueInit then continueInit() end
    _initDone = true
    return true
end

-- ============================================================
--  Voting-frame column injection
-- ============================================================

local currentSession = 1

local function canonRealmPart(s)
    return (s or ""):gsub("[%-_'%s%.]", ""):lower()
end

local function canonName(rcName)
    if not rcName then return nil end
    local n, r = rcName:match("^([^%-]+)%-(.+)$")
    if not n then return (rcName or ""):lower() end
    return n:lower() .. "~" .. canonRealmPart(r)
end

local canonIndex
local function buildCanonIndex()
    canonIndex = {}
    for fullKey in pairs(BlastRWishlistData or {}) do
        local c = canonName(fullKey)
        if c then canonIndex[c] = fullKey end
    end
end

local function invalidateCanonIndex() canonIndex = nil end

local function resolveCharKey(rcName)
    if not BlastRWishlistData or not rcName then return nil end
    if BlastRWishlistData[rcName] then return rcName end
    if not canonIndex then buildCanonIndex() end
    return canonIndex[canonName(rcName)]
end

local function getItemFromDiff(d, itemId)
    if not d or not d.items then return nil end
    local n = tonumber(itemId)
    return (n and d.items[n]) or d.items[tostring(itemId)]
end

local function findItemAnyDiff(spec, itemId)
    if not spec.diff then return nil end
    for _, key in ipairs({ "M", "H", "N", "R" }) do
        local hit = getItemFromDiff(spec.diff[key], itemId)
        if hit then return hit end
    end
    for _, d in pairs(spec.diff) do
        local hit = getItemFromDiff(d, itemId)
        if hit then return hit end
    end
    return nil
end

local function lookupWishlistItem(charKey, itemId, difficulty)
    local rec = BlastRWishlistData and BlastRWishlistData[charKey]
    if not rec or not rec.specs then return nil end
    local fallback
    for _, spec in pairs(rec.specs) do
        local item = getItemFromDiff(spec.diff and spec.diff[difficulty], itemId)
                  or findItemAnyDiff(spec, itemId)
        if item then
            if spec.is_main_spec then
                return item, spec, true
            end
            fallback = fallback or { item = item, spec = spec }
        end
    end
    if fallback then
        return fallback.item, fallback.spec, false
    end
    return nil
end

local function getCurrentDifficulty()
    local _, _, diffID = GetInstanceInfo()
    return DIFF_TOKEN[diffID or -1] or "M"
end

local function setCellSafe(frame, data, realrow, column, text, sortVal)
    if frame and frame.text then frame.text:SetText(text or "") end
    if data and data[realrow] and data[realrow].cols and data[realrow].cols[column] then
        data[realrow].cols[column].value = sortVal
    end
end

local function lookupForCell(data, realrow)
    local lootTable = RC:GetLootTable()
    local hasLoot = lootTable and lootTable[currentSession] ~= nil
    local hasRow = data and data[realrow] ~= nil
    local itemId = hasLoot and lootTable[currentSession].itemID
    local diff = getCurrentDifficulty()
    local rawName = hasRow and data[realrow].name
    local key = rawName and resolveCharKey(rawName)
    local item, spec, isMain
    if itemId and key then
        item, spec, isMain = lookupWishlistItem(key, itemId, diff)
    end
    if not hasLoot or not hasRow or not item then return nil end
    return item, spec, isMain, key
end

local function setCellPercent(_rowFrame, frame, data, _cols, _row, realrow, column)
    local item = lookupForCell(data, realrow)
    if not item then
        setCellSafe(frame, data, realrow, column, "", 0)
        return
    end
    local pct = item.percent or 0
    local color = pct > 0 and "|cff39FF14" or pct < 0 and "|cffFF6E84" or "|cffaaaaaa"
    setCellSafe(frame, data, realrow, column, string.format("%s%+.2f%%|r", color, pct), pct)
end

local TEX_BIS_PATH  = "Interface\\AddOns\\BlastR\\Media\\bis-star"
local TEX_LIST_PATH = "Interface\\AddOns\\BlastR\\Media\\list-dot"
local TEX_EQ_PATH   = "Interface\\AddOns\\BlastR\\Media\\eq-warning"
local TEX_BIS  = ("|T%s:14:14|t"):format(TEX_BIS_PATH)
local TEX_LIST = ("|T%s:14:14|t"):format(TEX_LIST_PATH)
local TEX_EQ   = ("|T%s:14:14|t"):format(TEX_EQ_PATH)

local function isItemInCuratedBis(data, realrow)
    local lootTable = RC and RC:GetLootTable()
    if not lootTable or not lootTable[currentSession] then return false end
    if not data or not data[realrow] then return false end
    local itemId = lootTable[currentSession].itemID
    local key = resolveCharKey(data[realrow].name)
    if not key then return false end
    local rec = BlastRWishlistData and BlastRWishlistData[key]
    local bis = rec and rec.bis_items
    if not bis then return false end
    local n = tonumber(itemId)
    return (n and bis[n]) or bis[tostring(itemId)] ~= nil
end

local function setCellBiSFlag(_rowFrame, frame, data, _cols, _row, realrow, column)
    if not isItemInCuratedBis(data, realrow) then
        setCellSafe(frame, data, realrow, column, "", 0)
        return
    end
    setCellSafe(frame, data, realrow, column, TEX_BIS, 1)
end

local function lookupListMembership(data, realrow)
    local lootTable = RC and RC:GetLootTable()
    local hasLoot = lootTable and lootTable[currentSession] ~= nil
    if not hasLoot or not data or not data[realrow] then return nil end
    local itemId = lootTable[currentSession].itemID
    local rawName = data[realrow].name
    local key = rawName and resolveCharKey(rawName)
    if not key then return nil end
    local rec = BlastRWishlistData and BlastRWishlistData[key]
    local map = rec and rec.list_items
    if not map then return nil end
    local id = tonumber(itemId)
    local names = (id and map[id]) or map[tostring(itemId)]
    if names and #names > 0 then return names end
    return nil
end

local function setCellListFlag(_rowFrame, frame, data, _cols, _row, realrow, column)
    local btn = frame.blastrListBtn
    if not btn then
        btn = CreateFrame("Button", nil, frame)
        btn:SetSize(16, 16)
        btn:SetPoint("CENTER")
        btn.tex = btn:CreateTexture(nil, "ARTWORK")
        btn.tex:SetAllPoints()
        btn.tex:SetTexture(TEX_LIST_PATH)
        frame.blastrListBtn = btn
    end

    local names = lookupListMembership(data, realrow)
    if not names then
        btn:Hide()
        setCellSafe(frame, data, realrow, column, "", 0)
        return
    end

    btn:Show()
    setCellSafe(frame, data, realrow, column, "", #names)
    btn:SetScript("OnEnter", function()
        GameTooltip:SetOwner(btn, "ANCHOR_RIGHT")
        GameTooltip:AddLine("|cff4fd3f7BlastR list|r")
        for _, n in ipairs(names) do
            GameTooltip:AddLine(n, 1, 1, 1)
        end
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

local function lookupCurrentlyEquipped(data, realrow)
    local lootTable = RC and RC:GetLootTable()
    if not lootTable or not lootTable[currentSession] then return false end
    if not data or not data[realrow] then return false end
    local itemId = lootTable[currentSession].itemID
    local key = resolveCharKey(data[realrow].name)
    if not key then return false end
    local rec = BlastRWishlistData and BlastRWishlistData[key]
    local cur = rec and rec.current_items
    if not cur then return false end
    local n = tonumber(itemId)
    if n and cur[n] then return true end
    return cur[tostring(itemId)] ~= nil
end

local function setCellEquippedFlag(_rowFrame, frame, data, _cols, _row, realrow, column)
    local btn = frame.blastrEqBtn
    if not btn then
        btn = CreateFrame("Button", nil, frame)
        btn:SetSize(16, 16)
        btn:SetPoint("CENTER")
        btn.tex = btn:CreateTexture(nil, "ARTWORK")
        btn.tex:SetAllPoints()
        btn.tex:SetTexture(TEX_EQ_PATH)
        frame.blastrEqBtn = btn
    end

    if not lookupCurrentlyEquipped(data, realrow) then
        btn:Hide()
        setCellSafe(frame, data, realrow, column, "", 0)
        return
    end

    btn:Show()
    setCellSafe(frame, data, realrow, column, "", 1)
    btn:SetScript("OnEnter", function()
        GameTooltip:SetOwner(btn, "ANCHOR_RIGHT")
        GameTooltip:AddLine("|cff4fd3f7BlastR|r")
        GameTooltip:AddLine("Already equipped", 1, 0.6, 0.2)
        GameTooltip:AddLine("This candidate already has this item.", 0.7, 0.7, 0.7, true)
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

local function setCellBlastRInfo(_rowFrame, frame, data, _cols, _row, realrow, column)
    local item, spec, isMain = lookupForCell(data, realrow)

    local btn = frame.blastrBtn
    if not btn then
        btn = CreateFrame("Button", nil, frame)
        btn:SetSize(16, 16)
        btn:SetPoint("CENTER")
        btn.tex = btn:CreateTexture(nil, "ARTWORK")
        btn.tex:SetAllPoints()
        btn.tex:SetTexture("Interface\\AddOns\\BlastR\\Media\\logo")
        frame.blastrBtn = btn
    end

    if not item then
        btn:Hide()
        setCellSafe(frame, data, realrow, column, "", 0)
        return
    end

    btn:Show()
    local rowName = data[realrow].name
    btn:SetScript("OnEnter", function()
        GameTooltip:SetOwner(btn, "ANCHOR_RIGHT")
        GameTooltip:AddLine("|cff4fd3f7BlastR|r")
        GameTooltip:AddLine(rowName, 1, 1, 1)
        if spec and spec.spec_name then
            local who = spec.spec_name
            if not isMain then who = who .. " (off-spec)" end
            GameTooltip:AddLine(who, 0.7, 0.7, 0.9)
        end
        local statusName = item.status == "b" and "BiS" or item.status == "n" and "Not best" or "Outdated"
        GameTooltip:AddLine("Status: " .. statusName)
        GameTooltip:AddLine(string.format("Upgrade: %+.2f%% (%+d)",
            item.percent or 0, item.value or 0))
        if item.source and item.source ~= "" then GameTooltip:AddLine("Source: " .. item.source, 0.7, 0.7, 0.7) end
        if item.boss and item.boss ~= "" then GameTooltip:AddLine("Boss: " .. item.boss, 0.9, 0.7, 0.3) end
        if item.note and item.note ~= "" then GameTooltip:AddLine("Note: " .. item.note, 0.7, 0.7, 0.7, true) end
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    setCellSafe(frame, data, realrow, column, "", 0)
end

local function indexOfCol(scrollCols, colName, fallback)
    for i, col in ipairs(scrollCols) do
        if col.colName == colName then return i end
    end
    return fallback
end

local function injectColumns()
    if not RCVotingFrame or not RCVotingFrame.scrollCols then
        if mod then mod:ScheduleTimer(injectColumns, 0.5) end
        return
    end
    for _, col in ipairs(RCVotingFrame.scrollCols) do
        if col.colName == "blastr_pct" then return end
    end

    local respIdx = indexOfCol(RCVotingFrame.scrollCols, "response", 4)
    local insertAt = respIdx + 1

    table.insert(RCVotingFrame.scrollCols, insertAt + 0, {
        name = "%", colName = "blastr_pct", width = 60, DoCellUpdate = setCellPercent,
    })
    table.insert(RCVotingFrame.scrollCols, insertAt + 1, {
        name = "BiS", colName = "blastr_bis", width = 30, align = "CENTER", DoCellUpdate = setCellBiSFlag,
    })
    table.insert(RCVotingFrame.scrollCols, insertAt + 2, {
        name = "List", colName = "blastr_list", width = 30, align = "CENTER", DoCellUpdate = setCellListFlag,
    })
    table.insert(RCVotingFrame.scrollCols, insertAt + 3, {
        name = "Eq", colName = "blastr_eq", width = 30, align = "CENTER", DoCellUpdate = setCellEquippedFlag,
    })
    table.insert(RCVotingFrame.scrollCols, {
        name = "BlastR", colName = "blastr_info", width = 50, align = "CENTER", DoCellUpdate = setCellBlastRInfo,
    })

    local f = RCVotingFrame.GetFrame and RCVotingFrame:GetFrame()
    if f and f.st then
        f.st:SetDisplayCols(RCVotingFrame.scrollCols)
        if f.st.frame and f.SetWidth then
            f:SetWidth(f.st.frame:GetWidth() + 20)
        end
    end
end

-- ============================================================
--  Loot history scanner
-- ============================================================
--
-- pendingTestDiffs: itemId → "M"|"H"|"N", consumed once. Set by
-- `/blastr test N` so that awarding a test item produces a
-- loot_distribution row stamped with the chosen difficulty regardless
-- of whether the player is currently in a raid instance.
local pendingTestDiffs = {}

-- Color shape RC stores varies: sometimes {r=1,g=1,b=1}, sometimes
-- {1,1,1}. Both produce the same hex; pick whichever fields exist.
local function colorToHex(c)
    if type(c) ~= "table" then return nil end
    local r = c.r or c[1]
    local g = c.g or c[2]
    local b = c.b or c[3]
    if type(r) ~= "number" or type(g) ~= "number" or type(b) ~= "number" then
        return nil
    end
    -- Both 0–1 floats and 0–255 ints show up in the wild; > 1 means int.
    if r <= 1 and g <= 1 and b <= 1 then
        r, g, b = r * 255, g * 255, b * 255
    end
    return string.format("#%02x%02x%02x",
        math.max(0, math.min(255, math.floor(r))),
        math.max(0, math.min(255, math.floor(g))),
        math.max(0, math.min(255, math.floor(b))))
end

-- Parse an itemString from an itemLink. Layout (after itemID) is:
--   :enchant:gem1:gem2:gem3:gem4:suffix:uniqueID:linkLevel:specID:upgradeType
--   :instanceDifficultyID:numBonusIDs:bonusID...
--
-- iLvl is NOT in the flat itemString — it's derived from base item +
-- bonus IDs. Use C_Item.GetDetailedItemLevelInfo() if available, fall
-- back to GetItemInfo(); both return the effective level for the link
-- as it appears in inventory.
local function parseItemLink(link)
    if type(link) ~= "string" then return nil end
    local itemId = tonumber(link:match("Hitem:(%d+)"))
    if not itemId then return nil end
    local enchant = tonumber(link:match("Hitem:%d+:(%d+)"))

    local ilvl
    if C_Item and C_Item.GetDetailedItemLevelInfo then
        ilvl = C_Item.GetDetailedItemLevelInfo(link)
    end
    if not ilvl and GetDetailedItemLevelInfo then
        ilvl = GetDetailedItemLevelInfo(link)
    end
    if not ilvl and GetItemInfo then
        local _name, _link, _q, gilvl = GetItemInfo(link)
        ilvl = gilvl
    end

    local segments = {}
    for seg in (link:gsub("|h.+", "")):gmatch(":([^:|]*)") do
        segments[#segments + 1] = seg
    end
    local bonusIds
    local bonusCount = tonumber(segments[12]) or 0
    if bonusCount > 0 then
        bonusIds = {}
        for i = 1, bonusCount do
            local id = tonumber(segments[12 + i])
            if id then bonusIds[#bonusIds + 1] = id end
        end
    end
    local gems = {}
    for i = 2, 5 do
        local id = tonumber(segments[i])
        if id and id > 0 then gems[#gems + 1] = id end
    end
    return {
        id        = itemId,
        ilvl      = ilvl and tonumber(ilvl) or nil,
        enchant   = (enchant and enchant > 0) and enchant or nil,
        bonus_ids = bonusIds,
        gems      = (#gems > 0) and gems or nil,
    }
end

-- Convert an RC entry id (epoch-counter, e.g. "1746649671-1") to ISO
-- UTC. The id's prefix is the master looter's wall-clock unix time at
-- award, which is what we actually want — it sidesteps RC's flaky
-- 2-digit-year `date` field and just trusts the timestamp the ML's
-- machine recorded.
local function entryIdToISO(entryId)
    if type(entryId) ~= "string" then return nowISO() end
    local epoch = tonumber(entryId:match("^(%d+)"))
    if not epoch or epoch <= 0 then return nowISO() end
    return date("!%Y-%m-%dT%H:%M:%SZ", epoch)
end

-- Encounter Journal index — `[localized boss name (lowercased)] = encounter_id`.
-- Built once on first scan by walking every encounter in every instance of
-- every tier. We rely on it to translate RC's locale-dependent boss string
-- into the locale-stable Blizzard journal id, so the backend can resolve
-- a canonical English name regardless of which client recorded the award.
--
-- Multiple tiers can have encounters with identical names (different tiers
-- of the same boss); we keep the highest tier (newest), which is what we
-- want for current-content loot. Built lazily so non-EJ clients don't pay
-- the index-build cost.
local _encounterIndex
local function buildEncounterIndex()
    local idx = {}
    if not (EJ_GetNumTiers and EJ_SelectTier and EJ_GetInstanceByIndex
            and EJ_SelectInstance and EJ_GetEncounterInfoByIndex) then
        return idx
    end

    local prevTier = (EJ_GetCurrentTier and EJ_GetCurrentTier()) or 1
    local prevInstance = (EJ_GetSelectedInstance and EJ_GetSelectedInstance()) or 0
    local numTiers = EJ_GetNumTiers() or 0

    for tier = numTiers, 1, -1 do
        EJ_SelectTier(tier)
        local i = 1
        while true do
            local instId, _instName = EJ_GetInstanceByIndex(i, true)  -- true = raids
            if not instId then break end
            EJ_SelectInstance(instId)
            local j = 1
            while true do
                local encName, _, encID = EJ_GetEncounterInfoByIndex(j)
                if not encName then break end
                if not idx[encName:lower()] then
                    idx[encName:lower()] = encID
                end
                j = j + 1
            end
            i = i + 1
        end
        local k = 1
        while true do
            local instId = EJ_GetInstanceByIndex(k, false)  -- false = dungeons
            if not instId then break end
            EJ_SelectInstance(instId)
            local j = 1
            while true do
                local encName, _, encID = EJ_GetEncounterInfoByIndex(j)
                if not encName then break end
                if not idx[encName:lower()] then
                    idx[encName:lower()] = encID
                end
                j = j + 1
            end
            k = k + 1
        end
    end

    -- Restore Encounter Journal selection so we don't disturb other addons.
    if EJ_SelectTier then EJ_SelectTier(prevTier) end
    if prevInstance and prevInstance > 0 and EJ_SelectInstance then
        pcall(EJ_SelectInstance, prevInstance)
    end
    return idx
end

local function resolveEncounterId(bossName)
    if type(bossName) ~= "string" or bossName == "" then return nil end
    if not _encounterIndex then _encounterIndex = buildEncounterIndex() end
    return _encounterIndex[bossName:lower()]
end

-- Build the bridge-payload for a single RC history entry. `playerKey`
-- is the lootDB top-level key (full Name-Realm) — it's the recipient.
local function buildEventFromEntry(playerKey, entry)
    local item = parseItemLink(entry.lootWon or entry.link)
    if not item then return nil end

    local diffToken = DIFF_TOKEN[entry.difficultyID or -1] or "?"
    -- /blastr test N override: if this item was picked for a test run,
    -- swap the difficulty to whatever we randomised at pick time. The
    -- map is consumed once so a real raid drop of the same item later
    -- isn't affected.
    if pendingTestDiffs[item.id] then
        diffToken = pendingTestDiffs[item.id]
        pendingTestDiffs[item.id] = nil
    end

    local responseText = entry.response
    local responseID = entry.responseID
    -- responseID is sometimes a string ("DISENCHANT") for award
    -- reasons; coerce to number when possible so methodFromResponse
    -- can match the canonical 1/2 path.
    local rid = tonumber(responseID) or responseID

    -- Raid slug: prefer the numeric mapID — slugifying entry.instance
    -- (a localized string like "Манафордж Омега (Епохальный)") with a
    -- naive pattern strips every Cyrillic glyph and we end up with "-"
    -- as the slug. mapID is locale-stable.
    local mapId = tonumber(entry.mapID)
    local raidSlug = mapId and ("instance-" .. mapId) or "unknown"

    -- Resolve whether `playerKey` is the local player. RC test mode
    -- always pipes awards through the master looter's own character
    -- (the mock candidates share the player's identity), so when
    -- candidate metadata is missing we can confidently substitute
    -- self-data for class + spec lookups.
    local function isSelf(key)
        local meName, meRealm = UnitName("player"), GetRealmName()
        if not meName then return false end
        local stripped = (meRealm or ""):gsub("%s+", "")
        return key == meName
            or key == meName .. "-" .. (meRealm or "")
            or key == meName .. "-" .. stripped
    end

    -- Class fallback: real raid entries arrive with `entry.class`
    -- populated, but test-mode mock candidates pass through with no
    -- class info (UnitClass(name) returns nil for non-roster units).
    -- Substitute the local player's class when the recipient is us.
    local resolvedClass = entry.class
    if (not resolvedClass) and isSelf(playerKey) then
        resolvedClass = select(2, UnitClass("player"))
    end

    -- Spec snapshot from RC's candidate registry (populated when raid
    -- members AceComm their playerSpec to the loot master before the
    -- vote). Same self-fallback for test mode where candidates are
    -- unpopulated.
    local rcCand = RC and RC.candidates and RC.candidates[playerKey]
    local recipSpecId = rcCand and tonumber(rcCand.specID)
    if not recipSpecId and isSelf(playerKey) then
        local idx = GetSpecialization and GetSpecialization()
        if idx and GetSpecializationInfo then
            recipSpecId = tonumber((GetSpecializationInfo(idx)))
        end
    end

    local isTestMode = (RC and RC.testMode) and true or false

    local event = {
        external_id = tostring(entry.id or ""),
        seq         = nextSeq,
        kind        = "loot_award",
        awarded_at  = entryIdToISO(entry.id),
        is_test_mode = isTestMode,

        raid = {
            slug         = raidSlug,
            difficulty   = diffToken,
            boss         = entry.boss,                       -- localized fallback
            encounter_id = resolveEncounterId(entry.boss),   -- locale-stable
            pull_id      = nil,
        },

        recipient          = playerKey,
        recipient_class    = resolvedClass,
        recipient_spec_id  = recipSpecId,
        awarded_by         = entry.owner ~= playerKey and entry.owner or nil,

        item = item,

        method             = methodFromResponse(rid, responseText),
        response = {
            text  = responseText,
            color = colorToHex(entry.color),
        },
        council_same_vote  = tonumber(entry.votes),
        is_award_reason    = entry.isAwardReason and true or false,
        note               = entry.note,
    }

    nextSeq = nextSeq + 1
    return event
end

-- Walk RC's lootDB once and append any entry whose `id` we haven't
-- seen to BlastROutboxEvents. Cheap to call repeatedly — first scan
-- emits historic data, every subsequent scan only catches new awards.
local function scanLootDB(reason)
    if not RC and ensureRegistered then ensureRegistered() end
    if not RC then return 0 end
    local db = (RC.GetHistoryDB and RC:GetHistoryDB())
            or (RC.lootDB and RC.lootDB.factionrealm)
    if type(db) ~= "table" then return 0 end

    BlastROutboxEvents = BlastROutboxEvents or {}
    BlastRSeenExternalIds = BlastRSeenExternalIds or {}

    local added = 0
    for playerKey, entries in pairs(db) do
        if type(entries) == "table" then
            for _, entry in ipairs(entries) do
                local extId = tostring(entry.id or "")
                if extId ~= "" and not BlastRSeenExternalIds[extId] then
                    local event = buildEventFromEntry(playerKey, entry)
                    if event then
                        table.insert(BlastROutboxEvents, event)
                        BlastRSeenExternalIds[extId] = true
                        added = added + 1
                    end
                end
            end
        end
    end

    if added > 0 then
        DEFAULT_CHAT_FRAME:AddMessage(string.format(
            "|cff4fd3f7BlastR|r — scanned %d new loot entr%s (%s); next sync will push.",
            added, added == 1 and "y" or "ies", reason or "scan"))
    end
    return added
end

-- ============================================================
--  /blastr test  — drives an RC test session with wishlist items
-- ============================================================

local function pickTestItemIdsWithDiff(count)
    count = count or 5

    local function slugify(s) return (s or ""):lower():gsub("'", ""):gsub("%s+", "-") end
    local pName, pRealm = UnitName("player"), GetRealmName()
    local playerKey = (pName or "") .. "-" .. slugify(pRealm)

    local own, other = {}, {}
    for charKey, char in pairs(BlastRWishlistData or {}) do
        local target = (charKey == playerKey) and own or other
        for _, spec in pairs(char.specs or {}) do
            for _, diff in pairs(spec.diff or {}) do
                for itemIdStr, item in pairs(diff.items or {}) do
                    if item.status == "b" then
                        target[#target + 1] = tonumber(itemIdStr)
                    end
                end
            end
        end
    end

    -- Dedupe across own+other before shuffling so the same item can't
    -- show up twice (sames item often appears in multiple specs).
    local seen, pool = {}, {}
    for _, id in ipairs(own) do
        if not seen[id] then seen[id] = true; pool[#pool + 1] = id end
    end
    for _, id in ipairs(other) do
        if not seen[id] then seen[id] = true; pool[#pool + 1] = id end
    end

    -- Fisher-Yates shuffle the dedup'd pool so each /blastr test gives
    -- a fresh draw rather than always the first N items in iteration
    -- order. math.randomseed on session start (in init) keeps reloads
    -- different too.
    for i = #pool, 2, -1 do
        local j = math.random(i)
        pool[i], pool[j] = pool[j], pool[i]
    end

    local ids = {}
    for i = 1, math.min(count, #pool) do
        ids[#ids + 1] = pool[i]
    end

    -- Stamp each picked item with a random difficulty. Mythic is the
    -- common case so it gets weight 3, then heroic 2, normal 1 — same
    -- ratio as a typical guild's drops, makes the test data realistic.
    local DIFF_POOL = { "M", "M", "M", "H", "H", "N" }
    local diffs = {}
    for _, id in ipairs(ids) do
        diffs[id] = DIFF_POOL[math.random(#DIFF_POOL)]
    end
    return ids, diffs
end

-- Hunt RC's history for any prior award of this item. The recorded
-- itemLink carries the bonus IDs (and therefore the correct ilvl); we
-- reuse it in the test session so RC's voting frame shows real ilvl
-- instead of the bare base item. Falls back to nil — caller hands the
-- bare itemID to ML:Test then.
local function findRealItemLink(itemId)
    if not RC then return nil end
    local db = (RC.GetHistoryDB and RC:GetHistoryDB())
            or (RC.lootDB and RC.lootDB.factionrealm)
    if type(db) ~= "table" then return nil end
    for _, entries in pairs(db) do
        if type(entries) == "table" then
            for _, entry in ipairs(entries) do
                local link = entry.lootWon or entry.link
                local id = link and tonumber(link:match("Hitem:(%d+)"))
                if id == itemId then return link end
            end
        end
    end
    return nil
end

local pendingTestItems

-- continueInit forward-declared near tryRegister; this is the body. It
-- runs exactly once (gated by ensureRegistered) and installs everything
-- that depends on RC being live: voting-frame columns, the ML:Test
-- monkey-patch (so /blastr test substitutes our wishlist picks), and
-- the loot-history scanner triggers.
continueInit = function()
    mod:RegisterMessage("RCSessionChangedPre", function(_, s)
        currentSession = s or 1
    end)
    -- Two-track award capture:
    --   1. scanLootDB() reads RC's persistent lootDB so historic entries
    --      and real-raid drops both come through.
    --   2. The message args also carry a fully-shaped history_table —
    --      use them directly so RC's test mode (which skips lootDB
    --      persistence in some versions) still produces an outbox event.
    --      BlastRSeenExternalIds dedups, so emitting from both paths is
    --      safe — whichever fires first wins, the other no-ops.
    mod:RegisterMessage("RCMLLootHistorySend", function(_, ...)
        local args = { ... }
        mod:ScheduleTimer(function(payload)
            scanLootDB("award")
            local history_table, winner = payload[1], payload[2]
            if type(history_table) == "table" and winner and history_table.id then
                local extId = tostring(history_table.id)
                BlastRSeenExternalIds = BlastRSeenExternalIds or {}
                if not BlastRSeenExternalIds[extId] then
                    local event = buildEventFromEntry(winner, history_table)
                    if event then
                        BlastROutboxEvents = BlastROutboxEvents or {}
                        table.insert(BlastROutboxEvents, event)
                        BlastRSeenExternalIds[extId] = true
                        DEFAULT_CHAT_FRAME:AddMessage(string.format(
                            "|cff4fd3f7BlastR|r — captured award from message (%s); next sync will push.",
                            extId))
                    end
                end
            end
        end, 0.5, args)
    end)

    if RCVotingFrame.OnEnable then
        mod:SecureHook(RCVotingFrame, "OnEnable", injectColumns)
    end
    injectColumns()

    local mlMod = RC:GetModule("RCLootCouncilML", true)
    if mlMod and mlMod.Test and not mlMod._blastrTestHooked then
        local origTest = mlMod.Test
        mlMod.Test = function(self, items)
            if pendingTestItems then
                items = pendingTestItems
                pendingTestItems = nil
            end
            return origTest(self, items)
        end
        mlMod._blastrTestHooked = true
    end

    -- Award capture — hooks both paths so we catch awards regardless of
    -- mode. RC test mode short-circuits TrackAndLogLoot via an explicit
    -- `if addon.testMode and not addon.nnp then return end` (ml_core.lua
    -- line 1245), so the persistent lootDB is never written and the
    -- RCMLLootHistorySend message never fires. We instead hook the
    -- popup-yes static callback which RC always invokes regardless of
    -- mode.
    --
    -- Hook 1 (real mode): TrackAndLogLoot — receives `(self, winner,
    -- link, responseID, boss, reason, session, candData, owner)`. After
    -- it runs, the history_table is in self.lootTable[session].history.
    --
    -- Hook 2 (test mode): AwardPopupOnClickYesCallback — receives
    -- `(awarded, session, winner, status, data, callback, ...)` where
    -- `data.link`, `data.responseID`, `data.reason`, `data.votes` etc.
    -- are populated. We synthesise an entry from those + GetInstanceInfo.

    if mlMod and type(mlMod.TrackAndLogLoot) == "function" and not mlMod._blastrTrackHooked then
        mod:SecureHook(mlMod, "TrackAndLogLoot", function(self, winner, link, responseID, boss, reason, session, candData, owner)
            -- The history_table that TrackAndLogLoot just populated lives
            -- on the lootTable entry. Real-mode awards go through here.
            local lt = self.lootTable and self.lootTable[session]
            local history_table = lt and lt.history
            if type(history_table) ~= "table" or not history_table.id then return end
            local extId = tostring(history_table.id)
            BlastRSeenExternalIds = BlastRSeenExternalIds or {}
            if BlastRSeenExternalIds[extId] then return end
            local event = buildEventFromEntry(winner, history_table)
            if event then
                BlastROutboxEvents = BlastROutboxEvents or {}
                table.insert(BlastROutboxEvents, event)
                BlastRSeenExternalIds[extId] = true
                DEFAULT_CHAT_FRAME:AddMessage(string.format(
                    "|cff4fd3f7BlastR|r — captured award via TrackAndLogLoot (%s).", extId))
            end
        end)
        mlMod._blastrTrackHooked = true
    end

    if mlMod and type(mlMod.AwardPopupOnClickYesCallback) == "function"
       and not mlMod._blastrPopupHooked then
        mod:SecureHook(mlMod, "AwardPopupOnClickYesCallback", function(awarded, session, winner, status, data)
            if not awarded or not winner or not data or not data.link then return end
            -- TrackAndLogLoot also fires on real awards and dedup wins;
            -- this branch effectively only contributes new rows in test
            -- mode (where TrackAndLogLoot's testMode short-circuit drops
            -- the row).
            local extId = string.format("%d-%d-%s", time(), session or 0, tostring(winner))
            BlastRSeenExternalIds = BlastRSeenExternalIds or {}
            if BlastRSeenExternalIds[extId] then return end

            -- Resolve the human-readable response label + colour the same
            -- way RC does in TrackAndLogLoot: prefer `reason` (an explicit
            -- award-reason like "Disenchant"), fall back to whatever
            -- GetResponse returns for the responseID + slot. Without this
            -- the loot-history UI shows "Unknown 5" instead of "Mainspec".
            local lt = mlMod.lootTable and mlMod.lootTable[session]
            local typeCode = (lt and lt.typeCode) or (data and data.typeCode)
            local equipLoc = (lt and lt.equipLoc) or (data and data.equipLoc) or "default"
            local responseObj
            if data.reason then
                responseObj = data.reason
            elseif data.responseID and RC.GetResponse then
                responseObj = RC:GetResponse(typeCode or equipLoc, data.responseID)
            end
            local responseText  = (responseObj and responseObj.text)
                              or (data.responseText)
                              or "Unknown"
            local responseColor = responseObj and responseObj.color

            local instName, _, diffID, diffName, _, _, _, mapID = GetInstanceInfo()
            local rcCand = RC.candidates and RC.candidates[winner]
            local entry = {
                id           = extId,
                lootWon      = data.link,
                response     = responseText,
                responseID   = data.responseID,
                color        = responseColor,
                class        = (rcCand and rcCand.class) or select(2, UnitClass(winner)),
                instance     = (instName or "?") .. "-" .. (diffName or "?"),
                boss         = data.boss or (addon and addon.bossName) or "Test Boss",
                difficultyID = diffID,
                mapID        = mapID,
                isAwardReason = data.reason and true or false,
                note         = data.note or (data.candData and data.candData.note),
                votes        = data.votes or (data.candData and data.candData.votes),
                owner        = winner,
                date         = date("!%Y/%m/%d"),
                time         = date("!%H:%M:%S"),
            }
            local event = buildEventFromEntry(winner, entry)
            if event then
                BlastROutboxEvents = BlastROutboxEvents or {}
                table.insert(BlastROutboxEvents, event)
                BlastRSeenExternalIds[extId] = true
                DEFAULT_CHAT_FRAME:AddMessage(string.format(
                    "|cff4fd3f7BlastR|r — captured award via popup (%s).", extId))
            end
        end)
        mlMod._blastrPopupHooked = true
    end

    DEFAULT_CHAT_FRAME:AddMessage("|cff4fd3f7BlastR|r — award hooks installed (TrackAndLogLoot + popup callback).")

    mod:ScheduleTimer(function() scanLootDB("login") end, 2)

    local wishCount = 0
    if type(BlastRWishlistData) == "table" then
        for _ in pairs(BlastRWishlistData) do wishCount = wishCount + 1 end
    end
    print(("|cff4fd3f7BlastR|r — RCLootCouncil integration ready (%d wishlist character(s)). /blastr test to try it."):format(wishCount))
end

local function startTest(count)
    count = count or 3
    -- Lazy register — if PLAYER_LOGIN ran before AceAddon registered RC,
    -- our `RC` stayed nil. ensureRegistered does both tryRegister and
    -- continueInit so the ML:Test monkey-patch is installed before we
    -- hand it our pending items (otherwise RC would seed its own random
    -- pool and ignore our picks).
    if not ensureRegistered() then
        print("|cff4fd3f7BlastR|r — RCLootCouncil not loaded; can't run test.")
        return
    end
    local ids, diffs = pickTestItemIdsWithDiff(count)
    if #ids == 0 then
        print("|cff4fd3f7BlastR|r — no wishlist items to test with. Sync first.")
        return
    end

    -- Print the picks + their assigned diffs so the user knows what to
    -- expect on the backend after they award the test items.
    print(string.format("|cff4fd3f7BlastR|r — test with %d item(s):", #ids))
    for _, id in ipairs(ids) do
        print(string.format("  %d → %s", id, diffs[id]))
    end

    -- Two parallel maps:
    --   pendingTestItems      → ML:Test consumes once for the item pool.
    --                           When we have a real link from RC's
    --                           history we hand that in (correct ilvl
    --                           + bonus IDs); otherwise we synthesise an
    --                           itemString with the season's mythic
    --                           difficulty bonus so the test UI shows a
    --                           realistic ilvl instead of bare item base.
    --   pendingTestDiffs      → scanner consumes per item to override
    --                           difficulty stamped on the loot row
    --
    -- Manaforge Omega season — these bonus IDs were observed in real
    -- award entries (12806 = mythic track, 9627/9633 = supporting). The
    -- mythic id alone is enough to push the link to mythic ilvl; we
    -- include the others so RC's tooltip preview matches what the loot
    -- master will actually see in the raid.
    local SEASON_BONUS_IDS = { M = 12806, H = 9633, N = 9627, R = 9626 }

    local items = {}
    for _, id in ipairs(ids) do
        local link = findRealItemLink(id)
        if not link then
            local bonus = SEASON_BONUS_IDS[diffs[id]] or SEASON_BONUS_IDS.M
            -- itemString layout: item:id:enchant:gem1-4:suffix:uniqueID:linkLevel:specID:upgradeType:instanceDifficultyID:numBonusIDs:bonus...
            link = string.format("item:%d:0:0:0:0:0:0:0:0:0:0:0:1:%d", id, bonus)
        end
        items[#items + 1] = link
    end
    pendingTestItems = items
    for id, d in pairs(diffs) do pendingTestDiffs[id] = d end

    local function tryInvoke()
        if type(RC.Test) == "function" then
            return pcall(RC.Test, RC, #ids)
        end
        if type(RC.ChatCommand) == "function" then
            return pcall(RC.ChatCommand, RC, "test " .. #ids)
        end
        local handler = SlashCmdList["ACECONSOLE_RC"]
                     or SlashCmdList["ACECONSOLE_RCLC"]
        if handler then return pcall(handler, "test " .. #ids) end
        return false, "no RC test entrypoint found"
    end

    local ok, err = tryInvoke()
    if not ok then
        print("|cffff5555BlastR|r — RC test invocation failed: " .. tostring(err))
        pendingTestItems = nil
        for id in pairs(diffs) do pendingTestDiffs[id] = nil end
    end
end

-- ============================================================
--  Slash commands
-- ============================================================

BlastR = BlastR or {}
BlastR.commands = BlastR.commands or {}
BlastR.commands["test"]      = function(rest) startTest(tonumber(rest) or 3) end
BlastR.commands["scanloot"]  = function() scanLootDB("manual") end

BlastR.commands["probeitem"] = function(rest)
    local itemId = tonumber(rest)
    if not itemId then print("|cff4fd3f7BlastR|r — usage: /blastr probeitem <itemId>"); return end
    print(("|cff4fd3f7BlastR|r — searching for item %d in BlastRWishlistData…"):format(itemId))
    local found = 0
    for charKey, char in pairs(BlastRWishlistData or {}) do
        for specId, spec in pairs(char.specs or {}) do
            for diffKey, diffData in pairs(spec.diff or {}) do
                local rec = getItemFromDiff(diffData, itemId)
                if rec then
                    found = found + 1
                    print(("  %s [%s/%s/%s]: status=%s value=%s percent=%s"):format(
                        charKey, tostring(specId), tostring(spec.spec_name), tostring(diffKey),
                        tostring(rec.status), tostring(rec.value), tostring(rec.percent)))
                end
            end
        end
    end
    if found == 0 then print("  (not found in any character/spec/difficulty)") end
    print(("  BlastRTimestamp: %s"):format(tostring(BlastRTimestamp)))
end

BlastR.commands["resetdebug"] = function()
    invalidateCanonIndex()
    print("|cff4fd3f7BlastR|r — canon index reset.")
end

BlastR.commands["probe"] = function()
    print("|cff4fd3f7BlastR probe|r")
    print("  RC global: " .. tostring(RC ~= nil))
    print("  RCVotingFrame: " .. tostring(RCVotingFrame ~= nil))
    print("  mod: " .. tostring(mod ~= nil))
    if _G.LibStub then
        local ace = _G.LibStub("AceAddon-3.0", true)
        print("  AceAddon-3.0: " .. tostring(ace ~= nil))
        if ace then
            local rc = ace:GetAddon("RCLootCouncil", true)
            print("  GetAddon('RCLootCouncil'): " .. tostring(rc ~= nil))
            if rc then
                print("  RC.Test: " .. tostring(type(rc.Test)))
                print("  RC.testMode: " .. tostring(rc.testMode))
                local ml = rc:GetModule("RCLootCouncilML", true)
                print("  ML module: " .. tostring(ml ~= nil))
                if ml then print("  ML.Test: " .. tostring(type(ml.Test))) end
                local vf = rc:GetModule("RCVotingFrame", true)
                print("  VotingFrame module: " .. tostring(vf ~= nil))
            end
        end
    else
        print("  LibStub: NOT FOUND")
    end
end

BlastR.commands["resolve"] = function(rest)
    if not rest or rest == "" then
        print("|cff4fd3f7BlastR|r — usage: /blastr resolve Name-Realm")
        return
    end
    local canon = canonName(rest)
    if not canonIndex then buildCanonIndex() end
    local hit = canonIndex[canon]
    print(("|cff4fd3f7BlastR|r resolve %q → canon=%q → match=%s")
        :format(rest, tostring(canon), tostring(hit)))
end

BlastR.commands["stats"] = function()
    if not RC then ensureRegistered() end
    print(("|cff4fd3f7BlastR stats|r — BlastRTimestamp=%s, BlastRSchema=%s"):format(
        tostring(BlastRTimestamp), tostring(BlastRSchema)))
    if not BlastRWishlistData then
        print("  (BlastRWishlistData is nil)")
    else
        local charKeys = {}
        for k in pairs(BlastRWishlistData) do charKeys[#charKeys + 1] = k end
        table.sort(charKeys)
        for _, charKey in ipairs(charKeys) do
            local rec = BlastRWishlistData[charKey]
            local function tcount(t) local n = 0; if type(t) == "table" then for _ in pairs(t) do n = n + 1 end end; return n end
            print(("  %s [%s] bis=%d current=%d list_items=%d"):format(
                charKey, tostring(rec.class),
                tcount(rec.bis_items), tcount(rec.current_items), tcount(rec.list_items)))
        end
    end
    -- Scanner state.
    local seenCount = 0
    for _ in pairs(BlastRSeenExternalIds or {}) do seenCount = seenCount + 1 end
    local outboxCount = #(BlastROutboxEvents or {})
    print(("  scanner: seen_external_ids=%d, outbox_events=%d, last_drained_at=%s")
        :format(seenCount, outboxCount, tostring(BlastROutboxLastDrainedAt)))
    if RC then
        local db = (RC.GetHistoryDB and RC:GetHistoryDB())
                or (RC.lootDB and RC.lootDB.factionrealm)
        local players, total = 0, 0
        if type(db) == "table" then
            for _, entries in pairs(db) do
                players = players + 1
                if type(entries) == "table" then total = total + #entries end
            end
        end
        print(("  RC lootDB: %d players, %d entries total"):format(players, total))
    end
end

-- ============================================================
--  Init
-- ============================================================

local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent", function(self, event)
    if event ~= "PLAYER_LOGIN" then return end
    self:UnregisterEvent("PLAYER_LOGIN")

    -- Reseed RNG so /reload between test sessions actually changes the
    -- random picks; default seed is constant per Lua state.
    math.randomseed(time())

    if ensureRegistered() then return end

    -- Schedule retries via a one-shot frame (no AceTimer yet — `mod`
    -- doesn't exist until tryRegister sets it). 0.5s ticks for 10s.
    local retryFrame = CreateFrame("Frame")
    local elapsed, attempts = 0, 0
    retryFrame:SetScript("OnUpdate", function(self, dt)
        elapsed = elapsed + dt
        if elapsed < 0.5 then return end
        elapsed = 0
        attempts = attempts + 1
        if ensureRegistered() then
            self:SetScript("OnUpdate", nil)
        elseif attempts >= 20 then
            self:SetScript("OnUpdate", nil)
            print("|cffff5555BlastR|r — RCLootCouncil never came online (10s timeout). Try /reload.")
        end
    end)
end)
