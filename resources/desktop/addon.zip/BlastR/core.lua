-- BlastR — root addon. Owns the wishlist SavedVariables (BlastR.lua,
-- written by the BlastR Desktop bridge) and provides the in-game
-- status window every loot master uses to verify wishes are fresh.
--
-- We never call into RC from here; RC integration (voting frame
-- columns, loot history hooks) lives entirely in BlastR_RCLootCouncil.

-- ============================================================
--  SavedVariables (declared in the .toc; just shapes here)
-- ============================================================
BlastRSchema             = BlastRSchema or 0
BlastRTimestamp          = BlastRTimestamp or nil
BlastRTeamID             = BlastRTeamID or 0
BlastRWishlistData       = BlastRWishlistData or {}
BlastRBridgeVersion      = BlastRBridgeVersion or "?"

-- ============================================================
--  Helpers
-- ============================================================

-- WoW Lua `time(t)` interprets the table as LOCAL time, NOT UTC — same
-- as standard Lua. A previous version of parseISO assumed otherwise,
-- which made every ISO timestamp render `(localOffset) hours older`
-- than reality (e.g. "3h ago" for a wishlist uploaded 5 min ago in
-- Kyiv summer time). We compute the local↔UTC delta once and add it
-- back so the returned epoch is true Unix UTC.
local function localUtcOffset()
    local now = time()
    local utcView = date("!*t", now)        -- now broken down as UTC fields
    utcView.isdst = false
    return now - time(utcView)               -- positive east of UTC
end
local TZ_OFFSET = localUtcOffset()

-- Parse an ISO-8601 string into a Unix UTC timestamp. WoW's stdlib has
-- no ISO parser so we tolerate a few common shapes ("Z" suffix and
-- "+HH:MM" / "-HH:MM" offsets) and fall back to nil if it doesn't match.
local function parseISO(s)
    if type(s) ~= "string" then return nil end
    local Y, M, D, h, m, sec, sign, ohh, omm =
        s:match("^(%d+)-(%d+)-(%d+)T(%d+):(%d+):(%d+)([Z%+%-]?)(%d?%d?):?(%d?%d?)")
    if not Y then return nil end
    local t = {
        year = tonumber(Y), month = tonumber(M), day = tonumber(D),
        hour = tonumber(h), min = tonumber(m), sec = tonumber(sec),
        isdst = false,
    }
    local epoch = time(t)
    if not epoch then return nil end
    -- Shift "interpreted as local" → real UTC for the ISO fields.
    epoch = epoch + TZ_OFFSET
    -- Then apply the ISO's own offset (UTC = local_in_iso - sign*offset).
    if sign == "+" or sign == "-" then
        local off = (tonumber(ohh) or 0) * 3600 + (tonumber(omm) or 0) * 60
        if sign == "+" then epoch = epoch - off else epoch = epoch + off end
    end
    return epoch
end

local function relativeAge(iso)
    local ts = parseISO(iso)
    if not ts then return "never" end
    local diff = time() - ts
    if diff < 60     then return ("%ds ago"):format(diff) end
    if diff < 3600   then return ("%dm ago"):format(diff / 60) end
    if diff < 86400  then return ("%dh ago"):format(diff / 3600) end
    if diff < 604800 then return ("%dd ago"):format(diff / 86400) end
    return ("%dw ago"):format(diff / 604800)
end

local FRESHNESS_DAYS_GREEN = 7
local FRESHNESS_DAYS_YELLOW = 30

local function freshnessColor(iso)
    local ts = parseISO(iso)
    if not ts then return 1.0, 0.45, 0.45 end -- red — missing
    local days = (time() - ts) / 86400
    if days < FRESHNESS_DAYS_GREEN  then return 0.27, 1.0, 0.27 end -- green
    if days < FRESHNESS_DAYS_YELLOW then return 1.0, 0.85, 0.30 end -- amber
    return 1.0, 0.45, 0.45                                          -- red
end

local function classColor(class)
    if class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class] then
        local c = RAID_CLASS_COLORS[class]
        return c.r, c.g, c.b
    end
    return 0.8, 0.8, 0.8
end

-- Splits "Name-realm-slug" into ("Name", "realm-slug"). Realm slugs
-- can contain hyphens (e.g. "tarren-mill"), so we match on the FIRST
-- hyphen — name itself never contains one.
local function splitCharKey(key)
    local name, realm = key:match("^([^%-]+)%-(.+)$")
    return name or key, realm or ""
end

-- Returns true if the player is currently in a raid group (not party).
local function inRaid()
    return IsInRaid and IsInRaid() or false
end

-- Build a set { ["Name-realm"] = true } of every character currently
-- in the player's raid group, normalized to the same shape used as
-- BlastRWishlistData keys.
local function raidMemberSet()
    local set = {}
    if not inRaid() then return set end
    for i = 1, GetNumGroupMembers() do
        local fullName, _, _, _, _, classToken = GetRaidRosterInfo(i)
        if fullName then
            -- Cross-realm raid members come back as "Name-RealmName"
            -- with the realm in display form; same-realm comes back as
            -- bare "Name". Normalize realm to lowercase slug shape.
            local n, r = fullName:match("^(.-)%-(.+)$")
            if not n then
                n = fullName
                r = (GetRealmName and GetRealmName() or ""):gsub(" ", "-"):lower()
            end
            set[n .. "-" .. r:lower()] = { class = classToken }
        end
    end
    return set
end

-- ============================================================
--  Window
-- ============================================================

local Frame
local Rows = {}
local raidFilter = false

-- Per-main expand state, keyed by the main's character key. Persists
-- only across redraws within a session — toggling a row never spills
-- to SavedVariables (cheap state, no need for it).
local expanded = {}

local function row(parent, idx)
    local r = CreateFrame("Frame", nil, parent)
    r:SetHeight(22)
    r:SetPoint("LEFT", 4, 0)
    r:SetPoint("RIGHT", -4, 0)

    -- Twisty (▶/▼) — only shown for mains with at least one alt.
    r.expander = CreateFrame("Button", nil, r)
    r.expander:SetSize(14, 14)
    r.expander:SetPoint("LEFT", 2, 0)
    r.expander.tex = r.expander:CreateTexture(nil, "OVERLAY")
    r.expander.tex:SetAllPoints(true)
    r.expander.tex:SetTexture("Interface\\Buttons\\UI-PlusButton-Up")
    r.expander:Hide()

    r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    r.name:SetPoint("LEFT", r.expander, "RIGHT", 6, 0)
    r.name:SetJustifyH("LEFT")

    r.role = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    r.role:SetPoint("LEFT", r.name, "RIGHT", 6, 0)

    r.age = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    r.age:SetPoint("RIGHT", -8, 0)
    r.age:SetJustifyH("RIGHT")

    return r
end

-- Build the display tree: every user_id collapses to one main; alts
-- hang under it and only render when expanded. Alts without a known
-- main bubble up as orphan rows so they aren't lost.
local function buildEntries()
    local raidSet = raidFilter and raidMemberSet() or nil

    local groups = {}        -- user_id → { main, alts[] }
    local orphans = {}       -- characters with no main in the snapshot

    for key, rec in pairs(BlastRWishlistData or {}) do
        if raidSet and not raidSet[key] then
            -- Skip; the raid filter excludes this whole user.
        else
            local uid = (rec and rec.user_id) or 0
            local entry = { key = key, rec = rec }
            if rec and rec.role == "main" then
                groups[uid] = groups[uid] or { alts = {} }
                groups[uid].main = entry
            else
                if uid == 0 or not (rec and rec.user_id) then
                    orphans[#orphans + 1] = entry
                else
                    groups[uid] = groups[uid] or { alts = {} }
                    table.insert(groups[uid].alts, entry)
                end
            end
        end
    end

    local out = {}
    for _, group in pairs(groups) do
        if group.main then
            local main = group.main
            main.altCount = #group.alts
            table.insert(out, main)
            if expanded[main.key] then
                table.sort(group.alts, function(a, b) return a.key < b.key end)
                for _, alt in ipairs(group.alts) do
                    alt.indent = true
                    table.insert(out, alt)
                end
            end
        else
            -- Group with no main — surface alts as top-level so loot
            -- master still sees them.
            for _, alt in ipairs(group.alts) do
                table.insert(out, alt)
            end
        end
    end
    for _, o in ipairs(orphans) do
        table.insert(out, o)
    end

    -- Sort top-level (mains + orphans) by freshness desc; alts already
    -- inserted right after their main so this preserves grouping.
    -- We sort while keeping each main's alts directly under it via a
    -- two-pass: extract main+alts blocks, sort the blocks, flatten.
    local blocks = {}
    local i = 1
    while i <= #out do
        local block = { out[i] }
        local j = i + 1
        while j <= #out and out[j].indent do
            table.insert(block, out[j])
            j = j + 1
        end
        blocks[#blocks + 1] = block
        i = j
    end
    table.sort(blocks, function(a, b)
        local ta = a[1].rec and parseISO(a[1].rec.last_updated_at) or 0
        local tb = b[1].rec and parseISO(b[1].rec.last_updated_at) or 0
        if ta == tb then return (a[1].key or "") < (b[1].key or "") end
        return ta > tb
    end)
    out = {}
    for _, block in ipairs(blocks) do
        for _, e in ipairs(block) do out[#out + 1] = e end
    end
    return out
end

local function rebuildList()
    if not Frame or not Frame:IsShown() then return end
    local content = Frame.scroll.child

    local entries = buildEntries()

    for _, r in ipairs(Rows) do r:Hide() end

    local mainsCount = 0
    for i, e in ipairs(entries) do
        local r = Rows[i]
        if not r then
            r = row(content, i)
            Rows[i] = r
        end
        r:ClearAllPoints()
        r:SetPoint("LEFT", 4, 0)
        r:SetPoint("RIGHT", -4, 0)
        r:SetPoint("TOP", content, "TOP", 0, -((i - 1) * 22))
        r:Show()

        local name, realm = splitCharKey(e.key)
        local class = e.rec and e.rec.class
        local cr, cg, cb = classColor(class)

        if e.indent then
            -- Alt row: indent, hide expander.
            r.expander:Hide()
            r.name:ClearAllPoints()
            r.name:SetPoint("LEFT", r, "LEFT", 32, 0)
            r.name:SetTextColor(cr * 0.85, cg * 0.85, cb * 0.85)
            r.name:SetText("↳ " .. name .. "  |cff5a5a5a" .. realm .. "|r")
        else
            mainsCount = mainsCount + 1
            -- Main (or orphan): show expander only when there are alts.
            if e.altCount and e.altCount > 0 then
                r.expander:Show()
                r.expander.tex:SetTexture(expanded[e.key]
                    and "Interface\\Buttons\\UI-MinusButton-Up"
                    or  "Interface\\Buttons\\UI-PlusButton-Up")
                local key = e.key
                r.expander:SetScript("OnClick", function()
                    expanded[key] = not expanded[key]
                    rebuildList()
                end)
            else
                r.expander:Hide()
            end
            r.name:ClearAllPoints()
            r.name:SetPoint("LEFT", r.expander, "RIGHT", 6, 0)
            r.name:SetTextColor(cr, cg, cb)
            local altsTag = (e.altCount and e.altCount > 0)
                and ("  |cff707070+" .. e.altCount .. "|r") or ""
            r.name:SetText(name .. "  |cff707070" .. realm .. "|r" .. altsTag)
        end

        r.role:SetText(e.rec and e.rec.role and e.rec.role:upper() or "")

        local age = e.rec and relativeAge(e.rec.last_updated_at) or "no wishlist"
        local fr, fg, fb = freshnessColor(e.rec and e.rec.last_updated_at)
        r.age:SetTextColor(fr, fg, fb)
        r.age:SetText(age)
    end

    content:SetHeight(math.max(1, #entries) * 22)
    -- "last load" not "last sync" — what the addon shows is the
    -- timestamp of the snapshot WoW loaded at the most recent
    -- /reload, NOT what's currently on disk. The bridge may have
    -- newer data sitting in BlastR.lua waiting for the next reload.
    Frame.summary:SetText(("|cff4fd3f7%d|r main(s) · loaded %s · /blastr sync to refresh")
        :format(mainsCount, relativeAge(BlastRTimestamp)))
end

local function buildFrame()
    if Frame then return Frame end

    local f = CreateFrame("Frame", "BlastRMainFrame", UIParent, "BackdropTemplate")
    f:SetSize(420, 460)
    f:SetPoint("CENTER")
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetClampedToScreen(true)
    f:SetFrameStrata("HIGH")

    f:SetBackdrop({
        bgFile   = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile     = true, tileSize = 16, edgeSize = 16,
        insets   = { left = 4, right = 4, top = 4, bottom = 4 },
    })
    f:SetBackdropColor(0.05, 0.05, 0.06, 0.95)
    f:SetBackdropBorderColor(0.31, 0.83, 0.97, 0.6)

    -- Header
    local logo = f:CreateTexture(nil, "OVERLAY")
    logo:SetTexture("Interface\\AddOns\\BlastR\\Media\\logo")
    logo:SetSize(28, 28)
    logo:SetPoint("TOPLEFT", 12, -10)

    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("LEFT", logo, "RIGHT", 8, 4)
    title:SetText("|cff4fd3f7BlastR|r")

    -- Version stamp lifted from the .toc, plus the bridge version the
    -- desktop app stamped into BlastRBridgeVersion via spec.writes —
    -- two independent paths surfacing in one label, so a quick glance
    -- at the frame proves both halves of the spec-driven pipeline
    -- (server → addon zip and server → SV write) are healthy.
    local addonVersion = (C_AddOns and C_AddOns.GetAddOnMetadata or GetAddOnMetadata)("BlastR", "Version") or "?"
    local bridgeVersion = BlastRBridgeVersion or "?"
    local subtitle = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    subtitle:SetPoint("LEFT", logo, "RIGHT", 8, -8)
    subtitle:SetText(("WISHLIST STATUS  ·  addon v%s  ·  bridge v%s"):format(addonVersion, bridgeVersion))

    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", 0, 0)

    -- Toolbar
    local sync = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    sync:SetSize(110, 22)
    sync:SetPoint("TOPLEFT", 12, -46)
    sync:SetText("Sync now")
    sync:SetScript("OnClick", function() BlastR:RequestSync() end)

    local raidBtn = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
    raidBtn:SetSize(22, 22)
    raidBtn:SetPoint("LEFT", sync, "RIGHT", 12, 0)
    raidBtn.text = raidBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    raidBtn.text:SetPoint("LEFT", raidBtn, "RIGHT", 2, 1)
    raidBtn.text:SetText("Raid only")
    raidBtn:SetChecked(raidFilter)
    raidBtn:SetScript("OnClick", function(self)
        raidFilter = self:GetChecked() and true or false
        rebuildList()
    end)

    f.summary = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    f.summary:SetPoint("RIGHT", -14, 0)
    f.summary:SetPoint("TOP", sync, "TOP", 0, 6)
    f.summary:SetJustifyH("RIGHT")

    -- List header
    local hdr = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hdr:SetPoint("TOPLEFT", 18, -78)
    hdr:SetText("CHARACTER")
    local hdr2 = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hdr2:SetPoint("TOPRIGHT", -18, -78)
    hdr2:SetText("UPDATED")

    -- Scroll list
    local scroll = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 8, -94)
    scroll:SetPoint("BOTTOMRIGHT", -28, 32)
    f.scroll = scroll

    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(380, 1)
    scroll:SetScrollChild(content)
    scroll.child = content

    -- Footer
    local footer = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    footer:SetPoint("BOTTOMLEFT", 12, 10)
    footer:SetPoint("BOTTOMRIGHT", -12, 10)
    footer:SetJustifyH("LEFT")
    footer:SetText(("schema %s · team %s · bridge %s"):format(
        tostring(BlastRSchema or "?"), tostring(BlastRTeamID or "?"), tostring(BlastRBridgeVersion or "?")))

    f:Hide()
    Frame = f
    return f
end

-- ============================================================
--  Public API + slash commands
-- ============================================================

BlastR = BlastR or {}

function BlastR:Toggle()
    local f = buildFrame()
    if f:IsShown() then f:Hide() else f:Show() rebuildList() end
end

function BlastR:Show()
    buildFrame():Show()
    rebuildList()
end

-- StaticPopup that prompts the user to reload. We can't call ReloadUI()
-- ourselves from addon code — it's a protected function and Blizzard
-- only allows it from secure contexts triggered by direct user input
-- (clicking this button counts; a C_Timer callback does not).
StaticPopupDialogs["BLASTR_SYNC_RELOAD"] = {
    text         = "|cff4fd3f7BlastR|r — sync requested. Reload UI to apply?",
    button1      = "Reload",
    button2      = "Later",
    OnAccept     = function() ReloadUI() end,
    timeout      = 0,
    whileDead    = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

-- RequestSync writes a flag the bridge's fsnotify watcher will see,
-- then asks the user for a /reload so WoW flushes the SV to disk and
-- re-reads whatever the bridge wrote in response. Used by the in-frame
-- button, the minimap button, and /blastr sync.
function BlastR:RequestSync()
    BlastROutboxSyncRequestedEpoch = time() * 1000  -- ms epoch for monotonic compare
    if InCombatLockdown and InCombatLockdown() then
        DEFAULT_CHAT_FRAME:AddMessage("|cff4fd3f7BlastR|r — in combat; sync flag set, reload prompt will appear when combat ends.")
        local g = CreateFrame("Frame")
        g:RegisterEvent("PLAYER_REGEN_ENABLED")
        g:SetScript("OnEvent", function(self)
            self:UnregisterEvent("PLAYER_REGEN_ENABLED")
            StaticPopup_Show("BLASTR_SYNC_RELOAD")
        end)
        return
    end
    StaticPopup_Show("BLASTR_SYNC_RELOAD")
end

-- Slash-command extension registry. Other BlastR modules (e.g. the
-- RCLootCouncil integration) attach handlers to BlastR.commands at
-- file-load time so they're available even before PLAYER_LOGIN. Built-
-- in commands defined directly in the dispatch below take priority.
BlastR.commands = BlastR.commands or {}

SLASH_BLASTR1 = "/blastr"
SlashCmdList["BLASTR"] = function(msg)
    -- Wrap the whole dispatch so a Lua error in any handler (including
    -- third-party-registered BlastR.commands) surfaces in chat instead
    -- of vanishing silently.
    local ok, err = pcall(function()
        msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
        local cmd, rest = msg:match("^(%S*)%s*(.*)$")
        cmd = cmd or ""

        DEFAULT_CHAT_FRAME:AddMessage(("|cff4fd3f7BlastR|r ▸ cmd=%q rest=%q"):format(cmd, rest or ""))

        if cmd == "" or cmd == "show" or cmd == "open" then
            BlastR:Show()
        elseif cmd == "toggle" then
            BlastR:Toggle()
        elseif cmd == "sync" then
            BlastR:RequestSync()
        elseif cmd == "status" then
            print("|cff4fd3f7BlastR|r")
            print(("  schema:    %s"):format(tostring(BlastRSchema or "?")))
            print(("  team_id:   %s"):format(tostring(BlastRTeamID or "?")))
            print(("  last load: %s (%s)"):format(tostring(BlastRTimestamp or "never"), relativeAge(BlastRTimestamp)))
            print(("  bridge:    %s"):format(tostring(BlastRBridgeVersion or "?")))
            local n = 0
            for _ in pairs(BlastRWishlistData or {}) do n = n + 1 end
            print(("  wishlists: %d character(s)"):format(n))
            print("  note: the bridge may have newer data on disk — /blastr sync to refresh.")
        elseif BlastR.commands[cmd] then
            BlastR.commands[cmd](rest)
        else
            local extras = ""
            for k in pairs(BlastR.commands) do extras = extras .. " | " .. k end
            print("|cff4fd3f7BlastR|r — usage: /blastr [show | sync | status" .. extras .. "]")
        end
    end)
    if not ok then
        DEFAULT_CHAT_FRAME:AddMessage("|cffff5555BlastR error:|r " .. tostring(err))
        if UIErrorsFrame then
            UIErrorsFrame:AddMessage("BlastR: " .. tostring(err), 1.0, 0.3, 0.3, 5)
        end
    end
end

-- ============================================================
--  Login banner
-- ============================================================

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(self)
    self:UnregisterEvent("PLAYER_LOGIN")
    if not BlastRTimestamp then
        DEFAULT_CHAT_FRAME:AddMessage("|cff4fd3f7BlastR|r — no sync data yet. Open BlastR Desktop and authorize.")
        return
    end
    DEFAULT_CHAT_FRAME:AddMessage(("|cff4fd3f7BlastR|r — wishlists ready. /blastr to open the panel.")
        :format(relativeAge(BlastRTimestamp)))
end)
