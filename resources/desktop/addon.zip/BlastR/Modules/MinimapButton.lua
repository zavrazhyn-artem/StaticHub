-- Minimap button for BlastR. Hand-rolled (no LibDBIcon) — single
-- addon, single button, not worth dragging in LibStub + LibDataBroker
-- + LibDBIcon just to avoid 80 lines of code.
--
-- Position is the angle (in degrees) around the minimap centre,
-- persisted in BlastRMinimapButton.angle so it survives /reload.
-- Right-click triggers sync; left-click toggles the status panel.

BlastRMinimapButton = BlastRMinimapButton or { angle = 220, hidden = false }

local BUTTON_SIZE    = 31
-- How far past the minimap edge the button sits. A few pixels of
-- overhang matches Calendar/Clock and avoids the button visually
-- hugging the inner ring of the minimap.
local EDGE_OUTSET    = 4

-- Minimap size varies by client/UI scale (WoW 10.x defaults to ~192px,
-- older builds were ~140px). Reading the live width every time means
-- the button stays on the edge even if the user resized the minimap.
local function minimapRadius()
    local w = Minimap:GetWidth() or 140
    return (w / 2) + EDGE_OUTSET
end

local function positionButton(button)
    local angle = math.rad(BlastRMinimapButton.angle or 220)
    local r = minimapRadius()
    local x = math.cos(angle) * r
    local y = math.sin(angle) * r
    button:ClearAllPoints()
    button:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

local function buildTooltip(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddDoubleLine("|cff4fd3f7BlastR|r", "wishlist sync")
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("|cffffffffLeft-click|r       open status panel", 0.7, 0.7, 0.7)
    GameTooltip:AddLine("|cffffffffRight-click|r      sync now (/reload)", 0.7, 0.7, 0.7)
    GameTooltip:AddLine("|cffffffffShift-drag|r       reposition", 0.7, 0.7, 0.7)
    GameTooltip:Show()
end

local function createButton()
    local btn = CreateFrame("Button", "BlastRMinimapButton_Frame", Minimap)
    btn:SetSize(BUTTON_SIZE, BUTTON_SIZE)
    btn:SetFrameStrata("MEDIUM")
    btn:SetFrameLevel(8)
    btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    btn:RegisterForDrag("LeftButton")
    btn:SetMovable(true)

    -- Background ring — same texture every other minimap button uses,
    -- so ours blends with Calendar/Clock/etc.
    local back = btn:CreateTexture(nil, "BACKGROUND")
    back:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    back:SetSize(20, 20)
    back:SetPoint("CENTER", 0, 1)
    back:SetVertexColor(1, 1, 1, 0.6)
    btn.back = back

    -- Logo. Cropped slightly with TexCoord so the whitespace around
    -- the BlastR mark doesn't clip into the ring.
    local icon = btn:CreateTexture(nil, "ARTWORK")
    icon:SetTexture("Interface\\AddOns\\BlastR\\Media\\logo")
    icon:SetSize(20, 20)
    icon:SetPoint("CENTER", 0, 1)
    icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    btn.icon = icon

    -- Standard minimap-button overlay ring.
    local border = btn:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(54, 54)
    border:SetPoint("TOPLEFT", 0, 0)
    btn.border = border

    btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    btn:SetScript("OnClick", function(_, button)
        if button == "RightButton" then
            if BlastR and BlastR.RequestSync then BlastR:RequestSync() end
        else
            if BlastR and BlastR.Toggle then BlastR:Toggle() end
        end
    end)

    btn:SetScript("OnDragStart", function(self)
        self:LockHighlight()
        -- OnUpdate tracks the cursor while held; computed angle saved
        -- on stop. 60Hz update is fine — nothing else moves on it.
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            cx, cy = cx / scale, cy / scale
            local angle = math.deg(math.atan2(cy - my, cx - mx))
            BlastRMinimapButton.angle = angle
            positionButton(self)
        end)
    end)
    btn:SetScript("OnDragStop", function(self)
        self:UnlockHighlight()
        self:SetScript("OnUpdate", nil)
    end)

    btn:SetScript("OnEnter", buildTooltip)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)

    return btn
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(self)
    self:UnregisterEvent("PLAYER_LOGIN")
    if BlastRMinimapButton.hidden then return end
    local btn = createButton()
    positionButton(btn)
end)
